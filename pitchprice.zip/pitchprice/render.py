"""HTML rendering for every page. Plain f-strings, no template engine needed."""
from datetime import datetime, timezone
from html import escape as e

import config

FONTS = ("https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700"
         "&family=Barlow+Condensed:wght@600;700&family=IBM+Plex+Mono:wght@500;700&display=swap")

BALL = ('<svg viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="14" fill="none" stroke="currentColor" stroke-width="2.5"/>'
        '<path d="M16 9l6 4.5-2.3 7h-7.4L10 13.5z" fill="currentColor"/></svg>')

LOCAL_TIME_JS = """<script>
(function(){try{var f=new Intl.DateTimeFormat(undefined,{hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
var d=new Intl.DateTimeFormat(undefined,{weekday:'short',day:'numeric',month:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
document.querySelectorAll('time[data-local]').forEach(function(t){var x=new Date(t.getAttribute('datetime'));
if(!isNaN(x)){t.textContent=(t.dataset.local==='long'?d:f).format(x);}});}catch(err){}})();
</script>"""


CUR = ' aria-current="page"'


def dt(utc):
    return datetime.fromisoformat(utc.replace("Z", "+00:00"))


def t_short(utc):
    return f'<time datetime="{e(utc)}" data-local="short">{dt(utc).strftime("%H:%M")} GMT</time>'


def t_long(utc):
    return f'<time datetime="{e(utc)}" data-local="long">{dt(utc).strftime("%a %d %b, %H:%M")} GMT</time>'


def day_label(utc):
    return dt(utc).strftime("%A %d %B")


def page(r, title, desc, body, active="", sample=False, ticker="", canonical=""):
    nav = [("index.html", "Home", "home"), ("fixtures.html", "Fixtures & odds", "fixtures"),
           ("results.html", "Results", "results"), ("leagues/index.html", "Tables", "tables"),
           ("news.html", "News", "news"), ("betting/index.html", "Betting sites", "betting")]
    nav_html = "".join(
        f'<a href="{r}{h}"{CUR if k == active else ""}>{t}</a>' for h, t, k in nav)
    help_links = []
    for reg in config.REGIONS.values():
        for name, url, _ in reg["help"]:
            if (name, url) not in help_links:
                help_links.append((name, url))
    rg = "".join(f'<a href="{e(u)}" rel="nofollow noopener" target="_blank">{e(n)}</a>' for n, u in help_links)
    banner = ('<div class="sample">SAMPLE DATA: fixtures, tables and odds below are made up. '
              'Add your API keys to show live data.</div>') if sample else ""
    can = f'<link rel="canonical" href="{e(config.SITE_URL.rstrip("/") + "/" + canonical)}">' if canonical else ""
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{e(title)}</title>
<meta name="description" content="{e(desc)}">
{can}
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="{FONTS}">
<link rel="stylesheet" href="{r}static/style.css">
</head>
<body>
{banner}
<header class="top"><div class="wrap">
<a class="brand" href="{r}index.html">{BALL}<span>{e(config.SITE_NAME[:5])}<b>{e(config.SITE_NAME[5:])}</b></span></a>
<nav class="nav" aria-label="Main">{nav_html}</nav>
<span class="age" title="Gambling content is for adults only">18+</span>
</div></header>
{ticker}
<main class="wrap">{body}</main>
<footer class="foot"><div class="wrap">
<div class="rg">{rg}</div>
<p>18+ only. Gambling can be addictive; set limits and never bet more than you can afford to lose. {e(config.SITE_NAME)} is an independent site. We may earn a commission when you join a bookmaker through our links, at no cost to you. Our model figures are estimates, not guarantees. Bookmaker offers are not shown in Australia, New Zealand or Kenya.</p>
<p><a href="{r}responsible-gambling.html">Responsible gambling</a> · <a href="{r}about.html">About &amp; affiliate disclosure</a> · Data: football-data.org, The Odds API.</p>
</div></footer>
{LOCAL_TIME_JS}
</body>
</html>"""


def ticker(r, results):
    if not results:
        return ""
    items = "".join(
        f'<li>{e(m["home_short"])}<span>{m["hg"]}–{m["ag"]}</span>{e(m["away_short"])}</li>' for m in results[:14])
    return f'<div class="ticker" aria-label="Latest results"><ul>{items}</ul></div>'


def fixture_list(r, matches, show_league=True, prices=True):
    """matches = list of dicts with keys m, league, slug, best, verdict."""
    if not matches:
        return '<p class="small">No matches in this window.</p>'
    out, cur = [], None
    for x in matches:
        m = x["m"]
        d = day_label(m["utc"])
        if d != cur:
            if cur is not None:
                out.append("</ul>")
            out.append(f'<div class="day">{d}</div><ul class="fx">')
            cur = d
        lg = f'<span class="lg">{e(x["league"]["name"])}</span>' if show_league else ""
        if m["status"] == "FINISHED":
            right = f'<span class="score">{m["hg"]}–{m["ag"]}</span>'
            left = '<span class="time">FT</span>'
        else:
            left = f'<span class="time">{t_short(m["utc"])}</span>'
            b, v = x.get("best"), x.get("verdict")
            if prices and b:
                cells = []
                for k in ("home", "draw", "away"):
                    cls = ' class="val"' if v and v["kind"] == "value" and v["outcome"] == k else ""
                    cells.append(f'<span{cls}>{b[k][0]:.2f}</span>')
                right = f'<span class="prices" aria-label="Best odds home, draw, away">{"".join(cells)}</span>'
            else:
                right = '<span class="small">Preview</span>'
        out.append(f'<li><a class="row" href="{r}{x["slug"]}">{left}<span class="teams">{lg}'
                   f'<span>{e(m["home_short"])}</span><span>{e(m["away_short"])}</span></span>{right}</a></li>')
    out.append("</ul>")
    return "".join(out)


def table_html(rows, compact=False, zones=(4, 3)):
    n = len(rows)
    head = ('<tr><th>#</th><th class="l">Team</th><th>P</th>' +
            ('' if compact else '<th>W</th><th>D</th><th>L</th><th>GF</th><th>GA</th>') +
            '<th>GD</th><th>Pts</th></tr>')
    body = []
    for row in rows:
        cls = "zone-top" if row["pos"] <= zones[0] else "zone-bot" if row["pos"] > n - zones[1] else ""
        extra = "" if compact else (f'<td>{row["won"]}</td><td>{row["draw"]}</td><td>{row["lost"]}</td>'
                                    f'<td>{row["gf"]}</td><td>{row["ga"]}</td>')
        gd = f'+{row["gd"]}' if row["gd"] > 0 else str(row["gd"])
        body.append(f'<tr class="{cls}"><td>{row["pos"]}</td><td class="l team">{e(row["short"])}</td>'
                    f'<td>{row["played"]}</td>{extra}<td>{gd}</td><td class="pts">{row["pts"]}</td></tr>')
    return f'<div class="scroll"><table><thead>{head}</thead><tbody>{"".join(body)}</tbody></table></div>'


def region_strip(r, current=None):
    links = [f'<a href="{r}betting/{k}.html"{CUR if k == current else ""}>{e(v["name"])}</a>'
             for k, v in config.REGIONS.items()]
    return f'<nav class="regions" aria-label="Choose your country">{"".join(links)}</nav>'


def go_link(r, slug):
    return f"{r}go/{slug}"
