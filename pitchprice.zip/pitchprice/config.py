"""
PitchPrice site settings.
Edit this file to rename the site, change leagues, add affiliate links,
or switch a region's affiliate links on or off.
"""

# --- Brand -----------------------------------------------------------------
SITE_NAME = "PitchPrice"
SITE_TAGLINE = "Football scores, tables and the best odds, updated twice a day"
SITE_URL = "https://pitchprice.netlify.app"   # change to your own domain once you have one
CONTACT_EMAIL = "hello@example.com"           # shown on the About page

# --- Competitions (football-data.org free tier codes) -----------------------
LEAGUES = [
    {"code": "PL",  "slug": "premier-league",   "name": "Premier League",   "country": "England", "odds_key": "soccer_epl"},
    {"code": "PD",  "slug": "la-liga",          "name": "La Liga",          "country": "Spain",   "odds_key": "soccer_spain_la_liga"},
    {"code": "SA",  "slug": "serie-a",          "name": "Serie A",          "country": "Italy",   "odds_key": "soccer_italy_serie_a"},
    {"code": "BL1", "slug": "bundesliga",       "name": "Bundesliga",       "country": "Germany", "odds_key": "soccer_germany_bundesliga"},
    {"code": "FL1", "slug": "ligue-1",          "name": "Ligue 1",          "country": "France",  "odds_key": "soccer_france_ligue_one"},
    {"code": "CL",  "slug": "champions-league", "name": "Champions League", "country": "Europe",  "odds_key": "soccer_uefa_champs_league"},
]

# How many days of results / fixtures to show
RESULTS_DAYS_BACK = 7
FIXTURES_DAYS_AHEAD = 7
FORM_DAYS_BACK = 35        # history used for team form

# --- Odds (The Odds API) ----------------------------------------------------
# Free plan = 500 credits a month. Each league costs 1 credit per region.
# 6 leagues x 2 regions x once a day = about 360 credits a month.
ODDS_REGIONS = "uk,eu"
ODDS_REFRESH_HOURS = 20    # odds are re-fetched at most once every 20 hours

# --- News (headlines + links only; article text is never copied) -------------
NEWS_FEEDS = [
    ("BBC Sport", "https://feeds.bbci.co.uk/sport/football/rss.xml"),
    ("The Guardian", "https://www.theguardian.com/football/rss"),
]
NEWS_MAX_ITEMS = 24

# --- Regions ------------------------------------------------------------------
# countries = ISO codes Netlify uses for geo redirects.
# affiliates_enabled = False keeps the region as content only (no affiliate buttons).
REGIONS = {
    "uk": {
        "name": "UK & Ireland",
        "countries": ["gb", "ie", "im", "je", "gg"],
        "affiliates_enabled": True,
        "age": 18,
        "help": [
            ("BeGambleAware", "https://www.begambleaware.org", "UK"),
            ("GAMSTOP self-exclusion", "https://www.gamstop.co.uk", "UK"),
            ("National Gambling Helpline 0808 8020 133", "https://www.gamcare.org.uk", "UK"),
            ("Gambling Care Ireland", "https://www.gamblingcare.ie", "Ireland"),
        ],
        "rules": "Only bookmakers licensed by the UK Gambling Commission are listed for UK readers. Irish readers should check a bookmaker holds an Irish licence.",
    },
    "ng": {
        "name": "Nigeria",
        "countries": ["ng"],
        "affiliates_enabled": True,
        "age": 18,
        "help": [("GamCare (international support)", "https://www.gamcare.org.uk", "International")],
        "rules": "Only bookmakers licensed in Nigeria (federal or state) are listed.",
    },
    "gh": {
        "name": "Ghana",
        "countries": ["gh"],
        "affiliates_enabled": True,
        "age": 18,
        "help": [("GamCare (international support)", "https://www.gamcare.org.uk", "International")],
        "rules": "Only bookmakers licensed by the Gaming Commission of Ghana are listed.",
    },
    "ke": {
        "name": "Kenya",
        "countries": ["ke"],
        "affiliates_enabled": False,
        "disabled_reason": "Kenya's Gambling Control Act 2025 requires gambling adverts to be approved by the regulator before publication. Turn this on only once you are cleared.",
        "age": 18,
        "help": [("GamCare (international support)", "https://www.gamcare.org.uk", "International")],
        "rules": "Content only. No bookmaker offers are shown to Kenyan readers.",
    },
    "au": {
        "name": "Australia & New Zealand",
        "countries": ["au", "nz"],
        "affiliates_enabled": False,
        "disabled_reason": "Australia's 2026 gambling reform law bans commissions paid to affiliates based on customer activity.",
        "age": 18,
        "help": [
            ("BetStop national self-exclusion", "https://www.betstop.gov.au", "Australia"),
            ("Gambling Help Online 1800 858 858", "https://www.gamblinghelponline.org.au", "Australia"),
            ("Gambling Helpline NZ 0800 654 655", "https://www.gamblinghelpline.co.nz", "New Zealand"),
        ],
        "rules": "Content only. No bookmaker offers are shown to Australian or New Zealand readers.",
    },
}

# --- Bookmakers -------------------------------------------------------------
# links: paste your affiliate tracking link for each region once you're approved.
# An empty link means no button is shown for that region.
# odds_keys: how this bookmaker appears in The Odds API data.
# summary: your own review text. Check every claim before you publish it.
BOOKMAKERS = [
    {"slug": "williamhill", "name": "William Hill", "regions": ["uk"], "odds_keys": ["williamhill"],
     "links": {"uk": ""},
     "summary": "Long-established UK bookmaker with deep football markets across all five major European leagues."},
    {"slug": "paddypower", "name": "Paddy Power", "regions": ["uk"], "odds_keys": ["paddypower"],
     "links": {"uk": ""},
     "summary": "Irish-founded bookmaker covering UK and Irish customers, with a wide range of football specials."},
    {"slug": "skybet", "name": "Sky Bet", "regions": ["uk"], "odds_keys": ["skybet"],
     "links": {"uk": ""},
     "summary": "UK bookmaker known for its football bet builder."},
    {"slug": "betfred", "name": "Betfred", "regions": ["uk"], "odds_keys": ["betfred"],
     "links": {"uk": ""},
     "summary": "UK high-street and online bookmaker with full coverage of European football."},
    {"slug": "ladbrokes", "name": "Ladbrokes", "regions": ["uk"], "odds_keys": ["ladbrokes_uk"],
     "links": {"uk": ""},
     "summary": "One of the UK's best-known bookmakers, part of the Entain group."},
    {"slug": "betway", "name": "Betway", "regions": ["uk", "ng", "gh"], "odds_keys": ["betway"],
     "links": {"uk": "", "ng": "", "gh": ""},
     "summary": "International bookmaker operating separately licensed sites in the UK, Nigeria and Ghana."},
    {"slug": "bet9ja", "name": "Bet9ja", "regions": ["ng"], "odds_keys": [],
     "links": {"ng": ""},
     "summary": "One of Nigeria's largest home-grown sportsbooks, with a heavy football focus."},
    {"slug": "sportybet", "name": "SportyBet", "regions": ["ng", "gh"], "odds_keys": [],
     "links": {"ng": "", "gh": ""},
     "summary": "Mobile-first sportsbook popular across West Africa, with mobile-money deposits."},
]

# Show example buttons when the site is running on sample data (so you can see the layout).
SHOW_DEMO_BUTTONS_ON_SAMPLE_DATA = True
