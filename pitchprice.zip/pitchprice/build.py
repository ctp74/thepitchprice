"""Build the whole site into ./dist.  Run:  python build.py
Uses live APIs when keys are in .env, otherwise sample data."""
import json
import os
import re
import shutil
import sys
from datetime import datetime, timedelta, timezone
from html import escape as e

import config
import fetch
import model
import render as R
import sample_data

HERE = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(HERE, "dist")


def log(msg):
    print(msg, flush=True)


def slugify(s):
    import unicodedata
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-")


def write(rel, html):
    path = os.path.join(DIST, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)


def load_data():
    fetch.load_env()
    fd_key, odds_key = os.environ.get("FOOTBALL_DATA_KEY"), os.environ.get("ODDS_API_KEY")
    codes = [lg["code"] for lg in config.LEAGUES]
    football = odds = news = None
    if fd_key:
        log("Fetching scores and tables...")
        football = fetch.fetch_football(fd_key, log)
    if football and odds_key:
        log("Fetching odds...")
        odds = fetch.fetch_odds(odds_key, log)
    log("Fetching news...")
    news = fetch.fetch_news(log)
    sample = football is None
    if sample:
        log("No live scores available, using SAMPLE data.")
        football, s_odds, s_news = sample_data.build(codes)
        odds = s_odds
        news = news or s_news
    return football, odds or {}, news or [], sample


def bookmaker_by_odds_key():
    out = {}
    for b in config.BOOKMAKERS:
        for k in b["odds_keys"]:
            out[k] = b
    return out


def has_cta(book, sample):
    if any(book["links"].get(r) and config.REGIONS[r]["affiliates_enabled"] for r in book["regions"]):
        return True
    return sample and config.SHOW_DEMO_BUTTONS_ON_SAMPLE_DATA and any(
        config.REGIONS[r]["affiliates_enabled"] for r in book["regions"])


def main():
    football, odds, news, sample = load_data()
    now = datetime.now(timezone.utc)
    stamp = now.strftime("%a %d %b %Y, %H:%M GMT")
    os.makedirs(DIST, exist_ok=True)
    shutil.copytree(os.path.join(HERE, "static"), os.path.join(DIST, "static"), dirs_exist_ok=True)
    bk_map = bookmaker_by_odds_key()

    upcoming, finished, sitemap = [], [], []
    league_data = {}
    for lg in config.LEAGUES:
        d = football.get(lg["code"], {"standings": [], "matches": []})
        rows = [r for t in d["standings"] for r in t["rows"]]
        avg, strg = model.strengths(rows)
        pos = {r["team"]: r["pos"] for t in d["standings"] if len(d["standings"]) == 1 for r in t["rows"]}
        fin = [m for m in d["matches"] if m["status"] == "FINISHED" and m["hg"] is not None]
        items = []
        for m in d["matches"]:
            kick = R.dt(m["utc"])
            slug = f'matches/{m["id"]}-{slugify(m["home_short"])}-vs-{slugify(m["away_short"])}.html'
            x = {"m": m, "league": lg, "slug": slug}
            if m["status"] == "FINISHED" and kick >= now - timedelta(days=config.RESULTS_DAYS_BACK):
                finished.append(x)
                items.append(x)
            elif m["status"] in ("SCHEDULED", "TIMED") and now - timedelta(hours=3) <= kick <= now + timedelta(days=config.FIXTURES_DAYS_AHEAD):
                if m["home"] == "TBC" or m["away"] == "TBC":
                    continue
                ev = model.match_odds(m, odds.get(lg["code"]))
                best, book_rows = model.best_prices(ev)
                pred = model.predict(m["home"], m["away"], avg, strg)
                v = model.verdict(pred, best)
                x.update(best=best, rows=book_rows, pred=pred, verdict=v,
                         form_h=model.form(m["home"], fin), form_a=model.form(m["away"], fin),
                         pos_h=pos.get(m["home"]), pos_a=pos.get(m["away"]))
                upcoming.append(x)
                items.append(x)
        league_data[lg["code"]] = {"lg": lg, "standings": d["standings"], "items": items}

    upcoming.sort(key=lambda x: x["m"]["utc"])
    finished.sort(key=lambda x: x["m"]["utc"], reverse=True)
    tick = R.ticker("", [x["m"] for x in finished])

    # ---- match pages
    for x in upcoming + finished:
        write(x["slug"], match_page(x, sample, stamp, bk_map))
        sitemap.append(x["slug"])

    # ---- home
    values = [x for x in upcoming if x["verdict"]["kind"] == "value"][:5]
    first = league_data[config.LEAGUES[0]["code"]]
    home_body = f"""
<section class="pagehead"><span class="eyebrow">Updated {stamp}</span>
<h1>Football odds, scores &amp; tables</h1>
<p>{e(config.SITE_TAGLINE)}. Every upcoming match in Europe's top five leagues and the Champions League, with the best price from each bookmaker and our model's fair odds.</p></section>
<div class="cols"><div>
<section class="block"><div class="blockhead"><h2>Next up</h2><a href="fixtures.html">All fixtures</a></div>
<p class="small">Best home / draw / away price across bookmakers. Gold marks a price our model rates as value.</p>
{R.fixture_list("", upcoming[:14])}</section>
<section class="block"><div class="blockhead"><h2>Latest results</h2><a href="results.html">All results</a></div>
{R.fixture_list("", finished[:8])}</section>
</div><aside>
{value_box("", values)}
<section class="block"><div class="blockhead"><h2>{e(first['lg']['name'])}</h2><a href="leagues/{first['lg']['slug']}.html">Full table</a></div>
{R.table_html(first['standings'][0]['rows'][:10], compact=True) if first['standings'] else ''}</section>
<section class="block"><div class="blockhead"><h2>Headlines</h2><a href="news.html">More</a></div>{news_list(news[:6])}</section>
<section class="block"><div class="blockhead"><h2>Betting sites</h2></div><p class="small">Pick your country to see bookmakers licensed where you live.</p>{R.region_strip("")}</section>
</aside></div>"""
    write("index.html", R.page("", f"{config.SITE_NAME}: football odds, scores & tables",
                               "Best football odds, live tables and results for the Premier League, La Liga, Serie A, Bundesliga, Ligue 1 and Champions League.",
                               home_body, "home", sample, tick, ""))
    sitemap.append("")

    # ---- fixtures & results
    write("fixtures.html", R.page("", f"Fixtures & best odds | {config.SITE_NAME}",
                                  "Upcoming fixtures with the best odds across bookmakers.",
                                  f'<section class="pagehead"><span class="eyebrow">Next {config.FIXTURES_DAYS_AHEAD} days</span><h1>Fixtures &amp; best odds</h1>'
                                  f'<p>Best home / draw / away price for each match. Gold marks a price our model rates as value. Tap a match for the full odds table and preview.</p></section>'
                                  f'<div class="block" style="padding-bottom:48px">{R.fixture_list("", upcoming)}</div>',
                                  "fixtures", sample, tick, "fixtures.html"))
    write("results.html", R.page("", f"Results | {config.SITE_NAME}", "Latest football results.",
                                 f'<section class="pagehead"><span class="eyebrow">Last {config.RESULTS_DAYS_BACK} days</span><h1>Results</h1></section>'
                                 f'<div class="block" style="padding-bottom:48px">{R.fixture_list("", finished)}</div>',
                                 "results", sample, tick, "results.html"))
    sitemap += ["fixtures.html", "results.html"]

    # ---- leagues
    cards = "".join(f'<a href="{lg["slug"]}.html"><b>{e(lg["name"])}</b><span>{e(lg["country"])}</span></a>' for lg in config.LEAGUES)
    write("leagues/index.html", R.page("../", f"League tables | {config.SITE_NAME}", "League tables for Europe's top competitions.",
                                       f'<section class="pagehead"><h1>League tables</h1></section><div class="leagues" style="padding-bottom:48px">{cards}</div>',
                                       "tables", sample, R.ticker("../", [x["m"] for x in finished]), "leagues/index.html"))
    sitemap.append("leagues/index.html")
    for code, ld in league_data.items():
        lg = ld["lg"]
        tables = ""
        for t in ld["standings"]:
            title = f'<h3>{e(t["group"].replace("_", " ").title())}</h3>' if t["group"] else ""
            zones = (8, 12) if code == "CL" else (4, 3)
            tables += title + R.table_html(t["rows"], zones=zones)
        up = [x for x in ld["items"] if x["m"]["status"] != "FINISHED"]
        fin = sorted([x for x in ld["items"] if x["m"]["status"] == "FINISHED"], key=lambda x: x["m"]["utc"], reverse=True)
        body = f"""<section class="pagehead"><span class="eyebrow">{e(lg['country'])}</span><h1>{e(lg['name'])}</h1>
<p class="updated">Updated {stamp}</p></section>
<div class="cols"><div>
<section class="block"><div class="blockhead"><h2>Table</h2></div>{tables or '<p class="small">Table not available yet.</p>'}</section>
</div><aside>
<section class="block"><div class="blockhead"><h2>Fixtures</h2></div>{R.fixture_list("../", up, show_league=False)}</section>
<section class="block"><div class="blockhead"><h2>Results</h2></div>{R.fixture_list("../", fin, show_league=False)}</section>
</aside></div>"""
        write(f"leagues/{lg['slug']}.html", R.page("../", f"{lg['name']} table, fixtures & odds | {config.SITE_NAME}",
                                                    f"{lg['name']} table, results, fixtures and best odds.", body, "tables", sample,
                                                    R.ticker("../", [x["m"] for x in finished]), f"leagues/{lg['slug']}.html"))
        sitemap.append(f"leagues/{lg['slug']}.html")

    # ---- news
    write("news.html", R.page("", f"Football news | {config.SITE_NAME}", "Latest football headlines.",
                              f'<section class="pagehead"><h1>Football news</h1><p>Latest headlines from around the game. Links open the full story on the publisher\'s site.</p></section>'
                              f'<div style="padding-bottom:48px;max-width:760px">{news_list(news)}</div>', "news", sample, tick, "news.html"))
    sitemap.append("news.html")

    # ---- betting pages
    betting_pages(sample, stamp, tick)
    sitemap += ["betting/index.html"] + [f"betting/{k}.html" for k in config.REGIONS]

    # ---- static pages
    static_pages(sample, tick)
    sitemap += ["responsible-gambling.html", "about.html"]

    # ---- redirects, sitemap, robots, headers
    write_redirects()
    urls = "".join(f"<url><loc>{e(config.SITE_URL.rstrip('/') + '/' + u)}</loc><lastmod>{now.date().isoformat()}</lastmod></url>" for u in sitemap)
    write("sitemap.xml", f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{urls}</urlset>')
    write("robots.txt", f"User-agent: *\nDisallow: /go/\nSitemap: {config.SITE_URL.rstrip('/')}/sitemap.xml\n")
    with open(os.path.join(DIST, "build-info.json"), "w") as f:
        json.dump({"built": now.isoformat(), "sample": sample, "upcoming": len(upcoming), "results": len(finished)}, f)
    log(f"Built {len(upcoming)} fixtures, {len(finished)} results, {len(news)} headlines -> {DIST}"
        + (" (SAMPLE DATA)" if sample else ""))


def value_box(r, values):
    if not values:
        return ""
    rows = "".join(
        f'<li><a class="row" href="{r}{x["slug"]}"><span class="time">{R.t_short(x["m"]["utc"])}</span>'
        f'<span class="teams"><span class="lg">{e(x["league"]["name"])}</span><span>{e(x["m"]["home_short"])} v {e(x["m"]["away_short"])}</span>'
        f'<span class="lg">{e(x["verdict"]["label"].capitalize())} @ {e(x["verdict"]["book"])}</span></span>'
        f'<span class="prices"><span class="val">{x["verdict"]["price"]:.2f}</span></span></a></li>' for x in values)
    return (f'<section class="block"><div class="blockhead"><h2>Value watch</h2></div>'
            f'<p class="small">Prices above our model\'s fair odds. Estimates only.</p><ul class="fx">{rows}</ul></section>')


def news_list(items):
    if not items:
        return '<p class="small">No headlines right now.</p>'
    li = []
    for n in items:
        when = f' · {R.t_long(n["utc"])}' if n.get("utc") else ""
        li.append(f'<li><a href="{e(n["link"])}" target="_blank" rel="noopener">{e(n["title"])}</a>'
                  f'<span class="src">{e(n["source"])}{when}</span></li>')
    return f'<ul class="news">{"".join(li)}</ul>'


def match_page(x, sample, stamp, bk_map):
    m, lg, r = x["m"], x["league"], "../"
    finished = m["status"] == "FINISHED"
    mid = f'<span class="score">{m["hg"]}–{m["ag"]}</span>' if finished else f'<span class="mono">{R.t_short(m["utc"])}</span>'
    stage = f'Matchday {m["matchday"]}' if m.get("matchday") else (m.get("stage") or "").replace("_", " ").title()
    head = f"""<section class="pagehead"><span class="eyebrow"><a href="{r}leagues/{lg['slug']}.html">{e(lg['name'])}</a> · {e(stage)}</span></section>
<div class="matchhead"><div class="vs"><div class="side">{e(m['home_short'])}</div><div class="mid">{mid}</div><div class="side">{e(m['away_short'])}</div></div>
<div class="meta"><span>{R.t_long(m['utc'])}</span><span>{'Full time' if finished else 'Kick-off in your local time'}</span></div></div>"""
    if finished:
        body = head + f'<div class="prose" style="padding-block:24px 48px"><p>{e(m["home_short"])} {m["hg"]}–{m["ag"]} {e(m["away_short"])}.</p><p><a href="{r}leagues/{lg["slug"]}.html">See the updated {e(lg["name"])} table</a>.</p></div>'
        return R.page(r, f"{m['home_short']} {m['hg']}-{m['ag']} {m['away_short']} | {lg['name']} result",
                      f"{m['home']} v {m['away']} result.", body, "results", sample, "", x["slug"])

    p, v = x["pred"], x["verdict"]
    bar = (f'<div class="probbar" role="img" aria-label="Model chances: home {model.pct(p["home"])}, draw {model.pct(p["draw"])}, away {model.pct(p["away"])}">'
           f'<div class="h" style="width:{p["home"]*100:.1f}%">{model.pct(p["home"])}</div>'
           f'<div class="d" style="width:{p["draw"]*100:.1f}%">{model.pct(p["draw"])}</div>'
           f'<div class="a" style="width:{p["away"]*100:.1f}%">{model.pct(p["away"])}</div></div>'
           f'<div class="legend"><span>{e(m["home_short"])} win</span><span>Draw</span><span>{e(m["away_short"])} win</span></div>')

    def form_box(name, f):
        chips = "".join(f'<i class="{res}" title="{e(lbl)}">{res}</i>' for res, lbl in f) or '<span class="small">No recent games</span>'
        lst = "".join(f"<li>{e(lbl)}</li>" for _, lbl in f)
        return f'<div><span class="eyebrow">{e(name)}</span><div class="form">{chips}</div><ol>{lst}</ol></div>'

    paras = "".join(f"<p>{e(t)}</p>" for t in model.preview_text(m, p, x["pos_h"], x["pos_a"], x["form_h"], x["form_a"], v))
    if v["kind"] == "value":
        vbox = (f'<div class="verdict"><span class="eyebrow">Our lean</span><h3>{e(v["label"].capitalize())} @ {v["price"]:.2f} with {e(v["book"])}</h3>'
                f'<span class="small">Model fair price {v["fair"]:.2f} · estimated edge {v["edge"]*100:.0f}%. Prices change; check before you bet.</span></div>')
    else:
        vbox = (f'<div class="verdict none"><span class="eyebrow">Our lean</span><h3>No value bet</h3>'
                f'<span class="small">Fair price for a {e(v["label"])}: {v["fair"]:.2f}</span></div>')

    if x["rows"]:
        trs = []
        for row in x["rows"]:
            bk = bk_map.get(row["key"])
            cta = f'<a class="cta" href="{R.go_link(r, bk["slug"])}" rel="sponsored nofollow">Bet</a>' if bk and has_cta(bk, sample) else ""
            cells = "".join(
                f'<td class="{"best" if abs(row[k] - x["best"][k][0]) < 1e-9 else ""}">{row[k]:.2f}</td>' for k in ("home", "draw", "away"))
            trs.append(f'<tr><td class="l team">{e(row["title"])}</td>{cells}<td class="l">{cta}</td></tr>')
        fair = "".join(f'<td>{1/p[k]:.2f}</td>' for k in ("home", "draw", "away"))
        odds_html = (f'<div class="scroll"><table><thead><tr><th class="l">Bookmaker</th><th>{e(m["home_short"])}</th><th>Draw</th><th>{e(m["away_short"])}</th><th></th></tr></thead>'
                     f'<tbody>{"".join(trs)}<tr><td class="l team">Our fair price</td>{fair}<td></td></tr></tbody></table></div>'
                     f'<p class="small">Decimal odds, last checked {stamp}. Highlighted cells are the best price. Bookmaker offers are only shown where they are licensed to operate. 18+.</p>')
    else:
        odds_html = '<p class="small">Odds are not available for this match yet.</p>'

    body = head + f"""<div class="cols" style="padding-top:24px"><div>
<section class="block"><div class="blockhead"><h2>Preview</h2></div><div class="prose">{paras}</div></section>
<section class="block"><div class="blockhead"><h2>Odds comparison</h2></div>{odds_html}</section>
<section class="block"><div class="blockhead"><h2>Recent form</h2></div><div class="formgrid">{form_box(m['home_short'], x['form_h'])}{form_box(m['away_short'], x['form_a'])}</div></section>
</div><aside>
{vbox}
<section class="block"><div class="blockhead"><h2>Model chances</h2></div>{bar}
<p class="small">Expected goals {p['xh']:.1f} – {p['xa']:.1f} · Over 2.5 goals {model.pct(p['over25'])} · Both teams score {model.pct(p['btts'])}</p>
<p class="small">Built from each team's goals for and against this season, with home advantage. Estimates, not guarantees.</p></section>
<section class="block"><div class="blockhead"><h2>Where to bet</h2></div><p class="small">See bookmakers licensed in your country.</p>{R.region_strip(r)}</section>
</aside></div>"""
    title = f"{m['home_short']} v {m['away_short']} odds, preview & prediction | {lg['name']}"
    desc = f"{m['home']} v {m['away']}: best odds compared, team form and our model's prediction."
    return R.page(r, title, desc, body, "fixtures", sample, "", x["slug"])


def betting_pages(sample, stamp, tick):
    r = "../"
    cards = "".join(f'<a href="{k}.html"><b>{e(v["name"])}</b><span>{"Bookmaker offers" if v["affiliates_enabled"] else "Betting guide"}</span></a>'
                    for k, v in config.REGIONS.items())
    write("betting/index.html", R.page(r, f"Betting sites by country | {config.SITE_NAME}", "Licensed betting sites for your country.",
                                       f'<section class="pagehead"><h1>Betting sites by country</h1><p>Gambling laws differ by country, so we only list bookmakers licensed where you live. Choose yours below.</p></section>'
                                       f'<div class="leagues" style="padding-bottom:48px">{cards}</div>', "betting", sample, tick, "betting/index.html"))
    for key, reg in config.REGIONS.items():
        helps = "".join(f'<li><a href="{e(u)}" target="_blank" rel="noopener">{e(n)}</a> <span class="small">({e(w)})</span></li>' for n, u, w in reg["help"])
        if reg["affiliates_enabled"]:
            books = [b for b in config.BOOKMAKERS if key in b["regions"]]
            cards = []
            for b in books:
                live = bool(b["links"].get(key))
                show = live or (sample and config.SHOW_DEMO_BUTTONS_ON_SAMPLE_DATA)
                cta = f'<a class="cta" href="{R.go_link(r, b["slug"])}" rel="sponsored nofollow">Visit {e(b["name"])}</a>' if show else '<span class="small">Link coming soon</span>'
                cards.append(f'<article class="book"><header><h3>{e(b["name"])}</h3>{cta}</header><p>{e(b["summary"])}</p>'
                             f'<p class="tc">18+. New customers only. Terms apply. Please gamble responsibly.</p></article>')
            main_html = f'<section class="block"><div class="blockhead"><h2>Bookmakers for {e(reg["name"])}</h2></div><div class="books">{"".join(cards)}</div></section>'
        else:
            main_html = (f'<div class="notice"><span class="eyebrow">Content only</span><p>{e(reg["rules"])}</p></div>'
                         f'<section class="block"><div class="blockhead"><h2>Using this site from {e(reg["name"])}</h2></div><div class="prose">'
                         f'<p>Scores, tables, previews and odds comparison are all available to you. Odds shown come from UK and European bookmakers and may differ from local prices.</p>'
                         f'<p>Only bet with operators licensed in your country, and use the support services below if betting stops being fun.</p></div></section>')
        body = f"""<section class="pagehead"><span class="eyebrow">Betting in {e(reg['name'])}</span><h1>Betting sites: {e(reg['name'])}</h1>
<p>{e(reg['rules'])} You must be {reg['age']} or over to bet.</p>{R.region_strip(r, key)}</section>
<div class="cols"><div>{main_html}</div><aside>
<section class="block"><div class="blockhead"><h2>Get support</h2></div><ul class="news">{helps}</ul></section>
<section class="block"><div class="blockhead"><h2>How we choose</h2></div><div class="prose small"><p>We only list bookmakers that hold a licence for your country. We may earn a commission when you sign up through our links; it never changes the odds you get.</p></div></section>
</aside></div>"""
        write(f"betting/{key}.html", R.page(r, f"Betting sites in {reg['name']} | {config.SITE_NAME}", f"Licensed football betting sites for {reg['name']}.",
                                            body, "betting", sample, tick, f"betting/{key}.html"))
    write("go/unavailable.html", R.page(r, f"Not available in your country | {config.SITE_NAME}", "Offer not available in your region.",
                                        f'<section class="pagehead"><h1>Not available where you are</h1><p>This bookmaker offer isn\'t available in your country. See the betting sites licensed for you instead.</p>{R.region_strip(r)}</section>',
                                        "betting", sample))


def static_pages(sample, tick):
    helps = ""
    for reg in config.REGIONS.values():
        items = "".join(f'<li><a href="{e(u)}" target="_blank" rel="noopener">{e(n)}</a></li>' for n, u, _ in reg["help"])
        helps += f'<section class="block"><h3>{e(reg["name"])}</h3><ul class="news">{items}</ul></section>'
    rg = f"""<section class="pagehead"><h1>Responsible gambling</h1><p>Betting should be entertainment, never a way to make money or solve money problems.</p></section>
<div class="cols"><div class="prose">
<p>You must be 18 or over to bet. Set a budget before you start and stick to it. Use the deposit limits, time-outs and self-exclusion tools every licensed bookmaker provides.</p>
<p>Warning signs include chasing losses, betting more than you planned, borrowing to bet, or hiding betting from people close to you. If any of these sound familiar, talk to one of the free, confidential services listed here.</p>
<p>Our match previews use a statistical model. Its figures are estimates. No prediction is certain, and past results don't guarantee future ones.</p>
</div><aside>{helps}</aside></div>"""
    write("responsible-gambling.html", R.page("", f"Responsible gambling | {config.SITE_NAME}", "Support and advice for safer gambling.",
                                              rg, "", sample, tick, "responsible-gambling.html"))
    about = f"""<section class="pagehead"><h1>About {e(config.SITE_NAME)}</h1></section>
<div class="prose" style="padding-bottom:48px">
<p>{e(config.SITE_NAME)} publishes football scores, tables, news headlines and odds comparison for Europe's top competitions. Pages are rebuilt twice a day.</p>
<h2>Affiliate disclosure</h2>
<p>We may earn a commission when you open an account with a bookmaker through links on this site. This doesn't affect the odds or offers you receive. We only show bookmaker offers in countries where we're permitted to and where the bookmaker is licensed.</p>
<h2>Where our data comes from</h2>
<p>Scores, fixtures and tables: football-data.org. Odds: The Odds API. Headlines link to the original publisher; we don't reproduce their articles.</p>
<h2>Contact</h2><p class="mono">{e(config.CONTACT_EMAIL)}</p>
</div>"""
    write("about.html", R.page("", f"About | {config.SITE_NAME}", f"About {config.SITE_NAME} and our affiliate disclosure.",
                               about, "", sample, tick, "about.html"))


def write_redirects():
    """Netlify _redirects: /go/<bookmaker>/ sends each country to its own affiliate link."""
    lines = ["# Generated by build.py. Edit affiliate links in config.py, not here."]
    for b in config.BOOKMAKERS:
        for reg_key in b["regions"]:
            reg = config.REGIONS[reg_key]
            link = b["links"].get(reg_key)
            if link and reg["affiliates_enabled"]:
                lines.append(f"/go/{b['slug']}  {link}  302!  Country={','.join(reg['countries'])}")
        lines.append(f"/go/{b['slug']}  /go/unavailable.html  302!")
    with open(os.path.join(DIST, "_redirects"), "w") as f:
        f.write("\n".join(lines) + "\n")
    with open(os.path.join(DIST, "_headers"), "w") as f:
        f.write("/*\n  X-Content-Type-Options: nosniff\n  Referrer-Policy: strict-origin-when-cross-origin\n"
                "/static/*\n  Cache-Control: public, max-age=86400\n")


if __name__ == "__main__":
    try:
        main()
    except Exception as ex:  # noqa: BLE001
        log(f"BUILD FAILED: {ex}")
        raise
        sys.exit(1)
