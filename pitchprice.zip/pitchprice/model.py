"""Match model (Poisson goals), odds matching and written previews."""
import difflib
import math
import re
import unicodedata
from datetime import datetime

HOME_EDGE = 1.12
AWAY_DAMP = 0.90
VALUE_EDGE = 0.05   # model must beat the best price by 5% to be called a value lean


def norm(name):
    s = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode().lower()
    s = re.sub(r"\b(fc|afc|cf|ac|sc|ssc|as|rc|ca|ud|cd|sv|vfb|vfl|tsg|bv|fk|club|de|calcio|1\.)\b", " ", s)
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def _sim(a, b):
    a, b = norm(a), norm(b)
    if not a or not b:
        return 0
    if a in b or b in a:
        return 0.95
    return difflib.SequenceMatcher(None, a, b).ratio()


def match_odds(match, events):
    """Find the odds event for a fixture (team names differ between the two APIs)."""
    best, best_score = None, 0
    day = match["utc"][:10]
    for e in events or []:
        if abs((datetime.fromisoformat(e["utc"].replace("Z", "+00:00")) -
                datetime.fromisoformat(match["utc"].replace("Z", "+00:00"))).total_seconds()) > 36 * 3600 and e["utc"][:10] != day:
            continue
        score = (_sim(match["home"], e["home"]) + _sim(match["away"], e["away"])) / 2
        if score > best_score:
            best, best_score = e, score
    return best if best_score >= 0.6 else None


def best_prices(event):
    """Returns {'home': (price, book), 'draw': ..., 'away': ...} plus the per-book rows."""
    if not event:
        return None, []
    rows = []
    best = {"home": (0, None), "draw": (0, None), "away": (0, None)}
    for b in event["books"]:
        p = b["prices"]
        h, a, d = p.get(event["home"]), p.get(event["away"]), p.get("Draw")
        if not (h and a and d):
            continue
        rows.append({"key": b["key"], "title": b["title"], "home": h, "draw": d, "away": a})
        for k, v in (("home", h), ("draw", d), ("away", a)):
            if v > best[k][0]:
                best[k] = (v, b["title"])
    if not rows:
        return None, []
    rows.sort(key=lambda r: r["title"].lower())
    return best, rows


def _pois(k, lam):
    return math.exp(-lam) * lam ** k / math.factorial(k)


def strengths(table_rows):
    played = sum(r["played"] for r in table_rows)
    goals = sum(r["gf"] for r in table_rows)
    avg = (goals / played) if played else 1.35
    out = {}
    for r in table_rows:
        if r["played"] >= 3:
            att = (r["gf"] / r["played"]) / avg
            dfn = (r["ga"] / r["played"]) / avg
            # shrink toward 1.0 early in the season
            w = min(r["played"], 12) / 12
            out[norm(r["team"])] = (1 + (att - 1) * w, 1 + (dfn - 1) * w)
    return avg, out


def predict(home, away, avg, strg):
    ha, hd = strg.get(norm(home), (1.0, 1.0))
    aa, ad = strg.get(norm(away), (1.0, 1.0))
    lh = max(0.2, avg * ha * ad * HOME_EDGE)
    la = max(0.2, avg * aa * hd * AWAY_DAMP)
    ph = pd = pa = over = btts = 0.0
    top = (0, 0, 0)
    for i in range(9):
        for j in range(9):
            p = _pois(i, lh) * _pois(j, la)
            if i > j:
                ph += p
            elif i == j:
                pd += p
            else:
                pa += p
            if i + j >= 3:
                over += p
            if i and j:
                btts += p
            if p > top[2]:
                top = (i, j, p)
    s = ph + pd + pa
    return {"xh": lh, "xa": la, "home": ph / s, "draw": pd / s, "away": pa / s,
            "over25": over, "btts": btts, "likely": (top[0], top[1])}


def form(team, finished):
    """Last five results for a team, newest first: list of ('W'|'D'|'L', label)."""
    out = []
    for m in sorted(finished, key=lambda x: x["utc"], reverse=True):
        if m["hg"] is None:
            continue
        if m["home"] == team:
            r = "W" if m["hg"] > m["ag"] else "D" if m["hg"] == m["ag"] else "L"
            out.append((r, f"{m['hg']}-{m['ag']} v {m['away_short']}"))
        elif m["away"] == team:
            r = "W" if m["ag"] > m["hg"] else "D" if m["hg"] == m["ag"] else "L"
            out.append((r, f"{m['ag']}-{m['hg']} at {m['home_short']}"))
        if len(out) == 5:
            break
    return out


def verdict(pred, best):
    """Pick a value lean (model probability x best price > 1 + VALUE_EDGE)."""
    labels = {"home": "home win", "draw": "draw", "away": "away win"}
    if not best:
        fav = max(("home", "draw", "away"), key=lambda k: pred[k])
        return {"kind": "none", "outcome": fav, "label": labels[fav], "fair": 1 / pred[fav]}
    cands = []
    for k in ("home", "draw", "away"):
        price, book = best[k]
        edge = pred[k] * price - 1
        cands.append((edge, k, price, book))
    edge, k, price, book = max(cands)
    if edge >= VALUE_EDGE:
        return {"kind": "value", "outcome": k, "label": labels[k], "price": price, "book": book,
                "edge": edge, "fair": 1 / pred[k]}
    fav = max(("home", "draw", "away"), key=lambda x: pred[x])
    return {"kind": "none", "outcome": fav, "label": labels[fav], "fair": 1 / pred[fav]}


def _form_phrase(name, f):
    if not f:
        return f"{name} have no recent results in our data."
    w = sum(1 for r, _ in f if r == "W")
    l = sum(1 for r, _ in f if r == "L")
    n = len(f)
    if w >= max(3, n - 1):
        tone = "arrive in strong form"
    elif l >= max(3, n - 1):
        tone = "are struggling for results"
    elif w > l:
        tone = "have been winning more than losing"
    elif l > w:
        tone = "have lost more than they've won lately"
    else:
        tone = "have been hard to call"
    return f"{name} {tone}, with {w} win{'s' if w != 1 else ''} from their last {n}."


def preview_text(m, pred, home_pos, away_pos, fh, fa, v):
    parts = []
    pos = []
    if home_pos:
        pos.append(f"{m['home_short']} sit {ordinal(home_pos)}")
    if away_pos:
        pos.append(f"{m['away_short']} are {ordinal(away_pos)}")
    if pos:
        parts.append(" and ".join(pos) + " in the table.")
    parts.append(_form_phrase(m["home_short"], fh))
    parts.append(_form_phrase(m["away_short"], fa))
    parts.append(
        f"Our model expects about {pred['xh']:.1f} goals for {m['home_short']} and {pred['xa']:.1f} for "
        f"{m['away_short']}, with {pred['likely'][0]}-{pred['likely'][1]} the single most likely score. "
        f"It gives a {pct(pred['over25'])} chance of three or more goals and {pct(pred['btts'])} that both teams score."
    )
    if v["kind"] == "value":
        parts.append(
            f"The best price on the {v['label']} is {v['price']:.2f} with {v['book']}. Our fair price is "
            f"{v['fair']:.2f}, so the bookmakers look slightly generous on this outcome."
        )
    else:
        parts.append(
            f"We don't see value in the 1X2 market here. Our fair price for the most likely outcome, "
            f"a {v['label']}, is {v['fair']:.2f}."
        )
    return parts


def ordinal(n):
    return f"{n}{'th' if 10 <= n % 100 <= 20 else {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')}"


def pct(p):
    return f"{round(p * 100)}%"
