"""Zip ./dist and publish it to Netlify through the Netlify API (no Netlify CLI needed).
Needs NETLIFY_TOKEN and NETLIFY_SITE_ID in .env."""
import io
import json
import os
import sys
import urllib.error
import urllib.request
import zipfile

import fetch

HERE = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(HERE, "dist")


def main():
    fetch.load_env()
    token, site = os.environ.get("NETLIFY_TOKEN"), os.environ.get("NETLIFY_SITE_ID")
    if not (token and site):
        print("Skipping deploy: add NETLIFY_TOKEN and NETLIFY_SITE_ID to .env")
        return 0
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(DIST):
            for name in files:
                full = os.path.join(root, name)
                z.write(full, os.path.relpath(full, DIST).replace(os.sep, "/"))
    req = urllib.request.Request(
        f"https://api.netlify.com/api/v1/sites/{site}/deploys", data=buf.getvalue(), method="POST",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/zip"})
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            info = json.loads(r.read())
        print(f"Deployed: {info.get('ssl_url') or info.get('url')} (state: {info.get('state')})")
        return 0
    except urllib.error.HTTPError as e:
        print(f"Deploy failed: HTTP {e.code} {e.read()[:300]!r}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
