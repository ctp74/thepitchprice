@echo off
REM Rebuilds PitchPrice and publishes it to Netlify. Windows Task Scheduler runs this twice a day.
cd /d "%~dp0"
if not exist logs mkdir logs
echo ===== %date% %time% ===== >> logs\update.log
python build.py >> logs\update.log 2>&1
if errorlevel 1 (
  echo Build failed, not deploying. >> logs\update.log
  exit /b 1
)
python deploy.py >> logs\update.log 2>&1
