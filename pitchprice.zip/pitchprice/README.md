# PitchPrice: soccer scores, odds and affiliate site

A static site that rebuilds itself twice a day on your mini agent PC and publishes to Netlify.
It needs only Python 3.9 or newer. No packages to install.

## What it builds

- **Home**: next fixtures with the best home/draw/away price, latest results, a "Value watch" list, a Premier League table snapshot, headlines and a country picker
- **Fixtures & odds** and **Results** pages
- **League pages** for the Premier League, La Liga, Serie A, Bundesliga, Ligue 1 and the Champions League, each with a table, fixtures and results
- **A page for every match**: written preview, odds comparison across bookmakers, recent form, model win/draw/loss chances, and a "lean" when a price beats the model's fair odds by 5% or more
- **News**: headlines that link to BBC Sport and The Guardian. Only the headline and link are used, never the article text.
- **Betting sites by country**: UK & Ireland, Nigeria, Ghana, Kenya, Australia & NZ
- **Responsible gambling** and **About & affiliate disclosure** pages, plus a `sitemap.xml` and `robots.txt`

Match pages stay on the site after the match is played, so search engines keep finding them.

## Setup (about 20 minutes)

1. **Copy the `pitchprice` folder** onto the mini agent PC, for example to `C:\PitchPrice`.
2. **Install Python** from python.org if it isn't already installed. Tick "Add python.exe to PATH" during setup.
3. **Get the free API keys:**
   - football-data.org: https://www.football-data.org/client/register (scores, fixtures, tables)
   - The Odds API: https://the-odds-api.com (odds; the free plan gives 500 credits a month)
4. **Create the Netlify site.** Run `python build.py` once. Then drag the `dist` folder onto Netlify Drop, the same way you set up The Stake Desk. Rename the site in Netlify. Copy its **Site ID** from Site configuration.
5. **Create a Netlify personal access token**: User settings > Applications > Personal access tokens.
6. **Copy `.env.example` to `.env`** and paste in the four values.
7. **Test it**: double-click `run_update.bat`, then check `logs\update.log`. The yellow SAMPLE DATA banner should be gone from the live site.
8. **Schedule it**: double-click `schedule_windows.bat`. This creates two daily jobs, at 6:00 AM and 1:00 PM on the PC's clock (Eastern Time).
   - The 6:00 AM run catches the overnight European results.
   - The 1:00 PM run catches weekend afternoon results and comes before the evening kick-offs.
   - On Mac or Linux, add `run_update.sh` to cron instead: `0 6,13 * * * /path/to/pitchprice/run_update.sh`

## Adding affiliate links

Open `config.py` and find `BOOKMAKERS`. Paste each tracking link into the matching region, for example `"links": {"uk": "https://your-tracking-link"}`. The next build adds the buttons.

Every button points to `/go/<bookmaker>`. Netlify then sends each visitor to the link for their own country. Anyone outside that bookmaker's licensed countries goes to a "Not available where you are" page instead. The rules are written to `dist/_redirects` on every build.

Before you go live, check that country redirects work on your Netlify plan. Visit `/go/williamhill` through a UK VPN, then again without one.

## Per-country rules built in

| Region | Affiliate buttons | Why |
|---|---|---|
| UK & Ireland | On | List only UK Gambling Commission-licensed bookmakers. Every offer needs 18+ and "terms apply" next to it. |
| Nigeria, Ghana | On | List only locally licensed bookmakers. |
| Kenya | **Off** | Under the Gambling Control Act 2025, gambling adverts must be approved by the regulator before they run. |
| Australia & NZ | **Off** | The 2026 reform law bans commissions paid to affiliates based on customer activity. |

To change a region, set `affiliates_enabled` in `config.py`. Turn Kenya on only once you are cleared by the regulator. I'm not a lawyer, so check each affiliate program's own terms as well.

The bookmaker summaries in `config.py` are short starter text. Before publishing, rewrite them in your own words and confirm every claim.

## Staying inside the free API limits

- **football-data.org:** about 12 calls per build, spaced out to respect the 10-calls-a-minute limit. A build takes about 90 seconds.
- **The Odds API:** odds are fetched at most once every 20 hours. That's 6 leagues x 2 regions = 12 credits a day, or about 360 a month. To refresh odds on both daily runs, change `ODDS_REFRESH_HOURS` to 10 and move to the paid plan.

If an API is down, the build reuses the last data it saved in `data/`. If there is no live data at all, it falls back to sample data and shows a banner.

## Files

| File | What it does |
|---|---|
| `config.py` | Site name, leagues, regions, bookmakers, affiliate links |
| `build.py` | Fetches the data and writes the site to `dist/` |
| `fetch.py` | Talks to the APIs and caches the results in `data/` |
| `model.py` | Goals model, matching odds to fixtures, preview text |
| `render.py` | Page layout |
| `static/style.css` | Site design, with light and dark themes |
| `deploy.py` | Uploads `dist/` to Netlify |
| `run_update.bat` / `.sh` | Build, then deploy (what the scheduler runs) |
| `schedule_windows.bat` | Creates the two daily Windows jobs |
