"""Sample data so the site builds before API keys are added. Every page shows a SAMPLE DATA banner."""
import math
import random
from datetime import datetime, timedelta, timezone

TEAMS = {
    "PL": ["Arsenal", "Aston Villa", "Bournemouth", "Brentford", "Brighton", "Chelsea", "Crystal Palace",
           "Everton", "Fulham", "Leeds United", "Liverpool", "Manchester City", "Manchester United",
           "Newcastle United", "Nottingham Forest", "Sunderland", "Tottenham Hotspur", "West Ham United",
           "Wolverhampton", "Burnley"],
    "PD": ["Real Madrid", "Barcelona", "Atlético Madrid", "Athletic Club", "Villarreal", "Real Betis",
           "Real Sociedad", "Sevilla", "Valencia", "Celta Vigo", "Osasuna", "Getafe", "Girona", "Mallorca",
           "Rayo Vallecano", "Espanyol", "Alavés", "Elche", "Levante", "Real Oviedo"],
    "SA": ["Inter", "Napoli", "Juventus", "AC Milan", "Atalanta", "Roma", "Lazio", "Fiorentina", "Bologna",
           "Como", "Torino", "Udinese", "Genoa", "Cagliari", "Lecce", "Parma", "Verona", "Sassuolo",
           "Cremonese", "Pisa"],
    "BL1": ["Bayern München", "Bayer Leverkusen", "Borussia Dortmund", "RB Leipzig", "Eintracht Frankfurt",
            "VfB Stuttgart", "SC Freiburg", "Wolfsburg", "Mainz 05", "Werder Bremen", "Union Berlin",
            "Borussia Mönchengladbach", "Hoffenheim", "Augsburg", "Heidenheim", "St. Pauli", "Köln", "Hamburger SV"],
    "FL1": ["Paris Saint-Germain", "Marseille", "Monaco", "Lille", "Lyon", "Nice", "Lens", "Rennes",
            "Strasbourg", "Brest", "Toulouse", "Nantes", "Auxerre", "Angers", "Le Havre", "Lorient",
            "Metz", "Paris FC"],
    "CL": ["Real Madrid", "Bayern München", "Paris Saint-Germain", "Manchester City", "Liverpool", "Arsenal",
           "Inter", "Barcelona", "Borussia Dortmund", "Atlético Madrid", "Juventus", "Benfica", "Porto",
           "PSV", "Club Brugge", "Celtic", "Napoli", "Bayer Leverkusen"],
}

SAMPLE_BOOKS = [("williamhill", "William Hill"), ("paddypower", "Paddy Power"), ("skybet", "Sky Bet"),
                ("ladbrokes_uk", "Ladbrokes"), ("betway", "Betway"), ("betfred", "Betfred")]


def _pois_sample(rng, lam):
    L, k, p = math.exp(-lam), 0, 1.0
    while True:
        p *= rng.random()
        if p <= L:
            return k
        k += 1


def build(league_codes):
    rng = random.Random(20261012)
    now = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
    football, odds = {}, {}
    mid = 9_000_000
    for code in league_codes:
        teams = TEAMS[code]
        n = len(teams)
        rating = {t: 1.6 - i * (1.0 / n) + rng.uniform(-0.15, 0.15) for i, t in enumerate(teams)}
        stats = {t: dict(played=0, won=0, draw=0, lost=0, gf=0, ga=0) for t in teams}
        matches = []
        rounds = 6 if code == "CL" else 8
        for rd in range(rounds + 1):
            order = teams[:]
            rng.shuffle(order)
            if rd < rounds:
                when = now - timedelta(days=(rounds - rd) * 7 - rng.randint(0, 2))
            else:
                when = now + timedelta(days=rng.randint(1, 5))
            for i in range(0, len(order) - 1, 2):
                h, a = order[i], order[i + 1]
                kick = when.replace(hour=rng.choice([12, 14, 15, 17, 19])) + timedelta(days=rng.choice([0, 0, 1]))
                mid += 1
                if rd < rounds:
                    hg = _pois_sample(rng, max(0.3, 1.45 * rating[h] / rating[a] ** 0.5 * 0.85))
                    ag = _pois_sample(rng, max(0.3, 1.15 * rating[a] / rating[h] ** 0.5 * 0.85))
                    for t, f, g in ((h, hg, ag), (a, ag, hg)):
                        s = stats[t]
                        s["played"] += 1
                        s["gf"] += f
                        s["ga"] += g
                        s["won" if f > g else "draw" if f == g else "lost"] += 1
                    status = "FINISHED"
                else:
                    hg = ag = None
                    status = "TIMED"
                matches.append({"id": mid, "utc": kick.isoformat().replace("+00:00", "Z"), "status": status,
                                "matchday": rd + 1, "stage": "LEAGUE_STAGE" if code == "CL" else "REGULAR_SEASON",
                                "home": h, "away": a, "home_short": h, "away_short": a, "hg": hg, "ag": ag})
        rows = []
        for t, s in stats.items():
            rows.append({"team": t, "short": t, "crest": None, "id": hash(t) % 10000, **s,
                         "gd": s["gf"] - s["ga"], "pts": s["won"] * 3 + s["draw"]})
        rows.sort(key=lambda r: (-r["pts"], -r["gd"], -r["gf"], r["team"]))
        for i, r in enumerate(rows, 1):
            r["pos"] = i
        football[code] = {"standings": [{"group": None, "rows": rows}], "matches": matches}
        evs = []
        for m in matches:
            if m["status"] != "TIMED":
                continue
            rh, ra = rating[m["home"]] * 1.1, rating[m["away"]]
            ph = rh ** 2 / (rh ** 2 + ra ** 2) * 0.74
            pa = 0.74 - ph
            pdr = 0.26
            books = []
            for key, title in SAMPLE_BOOKS:
                margin = rng.uniform(1.04, 1.08)
                books.append({"key": key, "title": title, "prices": {
                    m["home"]: round(1 / (ph * margin) * rng.uniform(0.97, 1.03), 2),
                    m["away"]: round(1 / (pa * margin) * rng.uniform(0.97, 1.03), 2),
                    "Draw": round(1 / (pdr * margin) * rng.uniform(0.97, 1.03), 2)}})
            evs.append({"home": m["home"], "away": m["away"], "utc": m["utc"], "books": books})
        odds[code] = evs
    news = [{"title": f"Sample headline {i + 1}: real headlines from your news feeds appear here",
             "link": "https://www.bbc.co.uk/sport/football", "source": src,
             "utc": (now - timedelta(hours=i * 3)).isoformat()}
            for i, src in enumerate(["BBC Sport", "The Guardian"] * 4)]
    return football, odds, news
