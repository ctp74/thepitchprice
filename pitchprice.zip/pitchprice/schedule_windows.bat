@echo off
REM Run once on the mini agent PC (double-click). Creates two daily Task Scheduler jobs:
REM 6:00 AM (overnight European results are in) and 1:00 PM (weekend afternoon results in, before evening kick-offs).
REM Times use the PC's own clock (Eastern Time).
cd /d "%~dp0"
schtasks /Create /F /TN "PitchPrice morning update" /TR "\"%~dp0run_update.bat\"" /SC DAILY /ST 06:00
schtasks /Create /F /TN "PitchPrice afternoon update" /TR "\"%~dp0run_update.bat\"" /SC DAILY /ST 13:00
echo.
echo Done. You can see both jobs in Task Scheduler under "PitchPrice".
pause
