"""Data fetching: football-data.org (scores/tables), The Odds API (odds), RSS (news).
Standard library only, so the mini PC needs nothing but Python 3.9+."""
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime

import config

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "data")
UA = {"User-Agent": "PitchPrice/1.0 (+site builder)"}


def load_env():
    path = os.path.join(HERE, ".env")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def _get(url, headers=None, timeout=30):
    req = urllib.request.Request(url, headers={**UA, **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(), dict(r.headers)


def _cache_path(name):
    os.makedirs(DATA_DIR, exist_ok=True)
    return os.path.join(DATA_DIR, name)


def _save(name, obj):
    with open(_cache_path(name), "w", encoding="utf-8") as f:
        json.dump(obj, f)


def _load(name):
    p = _cache_path(name)
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    return None


# --- football-data.org --------------------------------------------------------
FD_BASE = "https://api.football-data.org/v4"


def _fd(path, key):
    body, _ = _get(FD_BASE + path, {"X-Auth-Token": key})
    time.sleep(6.5)  # free tier: 10 calls a minute
    return json.loads(body)


def fetch_football(key, log):
    """Returns {league_code: {"standings": [...], "matches": [...]}} or None."""
    today = datetime.now(timezone.utc).date()
    out = {}
    for lg in config.LEAGUES:
        code = lg["code"]
        entry = {"standings": [], "matches": []}
        try:
            st = _fd(f"/competitions/{code}/standings", key)
            for table in st.get("standings", []):
                if table.get("type") == "TOTAL":
                    entry["standings"].append({
                        "group": table.get("group"),
                        "rows": [{
                            "pos": r["position"], "team": r["team"]["name"],
                            "short": r["team"].get("shortName") or r["team"]["name"],
                            "crest": r["team"].get("crest"), "id": r["team"]["id"],
                            "played": r["playedGames"], "won": r["won"], "draw": r["draw"], "lost": r["lost"],
                            "gf": r["goalsFor"], "ga": r["goalsAgainst"], "gd": r["goalDifference"], "pts": r["points"],
                        } for r in table.get("table", [])],
                    })
        except Exception as e:  # noqa: BLE001
            log(f"  standings {code} failed: {e}")
        windows = [(today - timedelta(days=config.FORM_DAYS_BACK), today + timedelta(days=config.FIXTURES_DAYS_AHEAD))]
        for frm, to in windows:
            try:
                q = urllib.parse.urlencode({"dateFrom": frm.isoformat(), "dateTo": to.isoformat()})
                m = _fd(f"/competitions/{code}/matches?{q}", key)
                for x in m.get("matches", []):
                    ft = (x.get("score") or {}).get("fullTime") or {}
                    entry["matches"].append({
                        "id": x["id"], "utc": x["utcDate"], "status": x["status"],
                        "matchday": x.get("matchday"), "stage": x.get("stage"),
                        "home": x["homeTeam"].get("name") or "TBC", "away": x["awayTeam"].get("name") or "TBC",
                        "home_short": x["homeTeam"].get("shortName") or x["homeTeam"].get("name") or "TBC",
                        "away_short": x["awayTeam"].get("shortName") or x["awayTeam"].get("name") or "TBC",
                        "hg": ft.get("home"), "ag": ft.get("away"),
                    })
            except Exception as e:  # noqa: BLE001
                log(f"  matches {code} failed: {e}")
        log(f"  {code}: {sum(len(t['rows']) for t in entry['standings'])} table rows, {len(entry['matches'])} matches")
        out[code] = entry
    if not any(v["matches"] for v in out.values()):
        return None
    _save("football.json", {"fetched": datetime.now(timezone.utc).isoformat(), "leagues": out})
    return out


# --- The Odds API -------------------------------------------------------------
def fetch_odds(key, log):
    """Returns {league_code: [events]}; uses a cache to stay inside the free quota."""
    cache = _load("odds.json")
    if cache:
        age = datetime.now(timezone.utc) - datetime.fromisoformat(cache["fetched"])
        if age < timedelta(hours=config.ODDS_REFRESH_HOURS):
            log(f"  odds cache is {age.seconds // 3600}h old, reusing it")
            return cache["leagues"]
    out = {}
    for lg in config.LEAGUES:
        q = urllib.parse.urlencode({"apiKey": key, "regions": config.ODDS_REGIONS,
                                    "markets": "h2h", "oddsFormat": "decimal"})
        url = f"https://api.the-odds-api.com/v4/sports/{lg['odds_key']}/odds?{q}"
        try:
            body, headers = _get(url)
            events = json.loads(body)
            out[lg["code"]] = [{
                "home": e["home_team"], "away": e["away_team"], "utc": e["commence_time"],
                "books": [{
                    "key": b["key"], "title": b["title"],
                    "prices": {o["name"]: o["price"] for m in b.get("markets", []) if m["key"] == "h2h" for o in m["outcomes"]},
                } for b in e.get("bookmakers", [])],
            } for e in events]
            log(f"  odds {lg['code']}: {len(events)} events (credits left: {headers.get('x-requests-remaining', '?')})")
        except Exception as e:  # noqa: BLE001
            log(f"  odds {lg['code']} failed: {e}")
            if cache:
                out[lg["code"]] = cache["leagues"].get(lg["code"], [])
    _save("odds.json", {"fetched": datetime.now(timezone.utc).isoformat(), "leagues": out})
    return out


# --- RSS news -----------------------------------------------------------------
def fetch_news(log):
    items = []
    for source, url in config.NEWS_FEEDS:
        try:
            body, _ = _get(url)
            root = ET.fromstring(body)
            for it in root.iter("item"):
                title = (it.findtext("title") or "").strip()
                link = (it.findtext("link") or "").strip()
                pub = it.findtext("pubDate")
                try:
                    when = parsedate_to_datetime(pub).astimezone(timezone.utc).isoformat() if pub else None
                except Exception:  # noqa: BLE001
                    when = None
                if title and link.startswith("http"):
                    items.append({"title": title, "link": link, "source": source, "utc": when})
            log(f"  news {source}: ok")
        except Exception as e:  # noqa: BLE001
            log(f"  news {source} failed: {e}")
    items.sort(key=lambda x: x["utc"] or "", reverse=True)
    items = items[: config.NEWS_MAX_ITEMS]
    if items:
        _save("news.json", items)
        return items
    return _load("news.json")
