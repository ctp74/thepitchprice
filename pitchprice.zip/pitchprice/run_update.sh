#!/bin/sh
# Rebuilds PitchPrice and publishes it to Netlify. cron runs this twice a day (Mac/Linux).
cd "$(dirname "$0")" || exit 1
mkdir -p logs
echo "===== $(date) =====" >> logs/update.log
python3 build.py >> logs/update.log 2>&1 || { echo "Build failed, not deploying." >> logs/update.log; exit 1; }
python3 deploy.py >> logs/update.log 2>&1
